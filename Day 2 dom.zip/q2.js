function openModal(src) {
    document.getElementById("modal").style.display = "flex";
    document.getElementById("modal-img").src = src;
}
function closeModal() {
    document.getElementById("modal").style.display = "none";
}